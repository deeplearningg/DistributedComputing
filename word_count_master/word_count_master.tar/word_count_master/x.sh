mpirun -np 5 ./run
