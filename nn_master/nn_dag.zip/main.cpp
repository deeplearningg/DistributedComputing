#include "nn.h"
#include "dagnode.h"
using namespace std;
int main(){

    Task *task0 = new Task(30000,2,0);//30000,2,0
    Task *task1 = new Task(30000,2,1);
    Task *task2 = new Task;

    DAGNode *DAGNode0 = new DAGNode(task0,Task::train,
                                     (void*)NULL,(void*)task0,NULL,0);// for createArr node
    DAGNode *DAGNode1 = new DAGNode(task1,Task::train,
                                     (void*)NULL,(void*)task1,DAGNode0,1);// for createArr node
    DAGNode *DAGNode2 = new DAGNode(task2,Task::merge,
                                     (void*)NULL,(void*)task2,DAGNode0,2);// merge two dicts

    DAGNode2->set_depedence(DAGNode0);
    DAGNode2->set_depedence(DAGNode1);


    DAGNode0->init_data();
    DAGNode1->init_data();
    DAGNode2->init_data();

    DAGNode0->display();

    (*DAGNode0->exec)( (void*)DAGNode0->data );
    (*DAGNode1->exec)( (void*)DAGNode1->data );
    (*DAGNode2->exec)( (void*)DAGNode2->data );

}
