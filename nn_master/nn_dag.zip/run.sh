mpirun -n 3 ./mpi_train
